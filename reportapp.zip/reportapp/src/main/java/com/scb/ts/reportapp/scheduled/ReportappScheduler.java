package com.scb.ts.reportapp.scheduled;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ReportappScheduler {
	
	/*@Scheduled(cron = "[Seconds] [Minutes] [Hours] [Day of month] [Month] [Day of week] [Year]")*/
	@Scheduled(cron = "5 34 22 1-7 1-12 ?")
		public void cronJobSch() {	
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			Date now = new Date();
			String strDate = sdf.format(now);
			System.out.println("Java cron job expression:: " + strDate);
		}

}
