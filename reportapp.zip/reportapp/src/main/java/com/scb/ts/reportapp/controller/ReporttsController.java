package com.scb.ts.reportapp.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ReporttsController {
	
	private String folderpath = "";
	
	
	private Map<Object, Object> propertyfiles;

	@GetMapping("/")
	public ModelAndView indexpage(Model model) throws IOException {
		Properties QuerySQLList = new Properties();

		InputStream is = null;
		is = this.getClass().getResourceAsStream("/application-filepath.properties");

		QuerySQLList.load(is);

		Map<Object, Object> mapOfList = new HashMap<Object, Object>();

		for (Entry<Object, Object> entry : QuerySQLList.entrySet()) {
			 mapOfList.put(entry.getKey(), entry.getValue());
//			mapOfList.put(entry.getValue(), entry.getKey());
		}
		propertyfiles = mapOfList;
		return new ModelAndView("index");
	}

	/* Reading the File List Java Method */
	@SuppressWarnings("rawtypes")
	public Map listFolders(String directoryName) {
		System.out.println("::::::::::listFolders::::::::::");
		File directory = new File(directoryName);
		Map<String, Object> filesList = new LinkedHashMap<>();
		// get all the files from a directory
		File[] fList = directory.listFiles();
		Arrays.sort(fList, Comparator.comparingLong(File::lastModified).reversed());
		System.out.println("file size" + fList.length);
		for (File file : fList) {
			if (file.isFile()) {
				filesList.put(file.getName(), file);
			}
		}
		System.out.println(filesList);
		return filesList;

	}

	@GetMapping("/tsIncidentreport")
	@SuppressWarnings("rawtypes")
	public ModelAndView tsIncidentreport(Model model) {
		return new ModelAndView("tsIncidentreport");
		
	}
	
	@GetMapping("/incidentmanagement")
	@SuppressWarnings("rawtypes")
	public ModelAndView incidentmanagement(Model model, @RequestParam("foldername") String foldername) {
//		String remedyincident001 = reporttsModel.getIncident001();
//		System.out.println("remedyincident001"+remedyincident001);
		String path = String.valueOf(propertyfiles.get(foldername));
		String header = String.valueOf(propertyfiles.get(foldername+"001"));
		System.out.println("path : "+path);
		System.out.println("header : "+header);
		folderpath = path;
		Map filesListIncident = listFolders(path);
		Map model1 = new HashMap<>();
		model1.put("header_name", header);
		model1.put("filesListIncidents", filesListIncident);
		return new ModelAndView("tsFileLoadpage", model1);
	}
	
	
	@GetMapping("/tsRetriggerPage")
	@SuppressWarnings("rawtypes")
	public ModelAndView tsRetriggerPage(Model model, @RequestParam("foldername") String foldername) {

		String path = String.valueOf(propertyfiles.get(foldername));
		String header = String.valueOf(propertyfiles.get(foldername+"001"));
		System.out.println("path : "+path);
		System.out.println("header : "+header);
		folderpath = path;
		Map<String,File> filesListRetrigger = listFolders(path);
		Map<String,File> filtered = new LinkedHashMap<String, File>();
		for(Entry<String,File> en : filesListRetrigger.entrySet()) {
			if(en.getKey().endsWith(".bat"))
				filtered.put(en.getKey(),en.getValue());
		}
		Map model1 = new HashMap<>();
		model1.put("header_name", header);
		model1.put("filesListRetrigger", filtered);
		return new ModelAndView("tsRetriggerPage", model1);
	}
	
	
	@GetMapping("/checkRetriggerList")
	@SuppressWarnings("rawtypes")
	public ModelAndView tsRetriggerPageAction(Model model, @RequestParam("checkRetriggerList") List<String> checkRetriggerList) {

		for(String filePath : checkRetriggerList) {
//		String filePath = "C:/Windows/Notepad.exe";
        try {
        	System.out.println("checkRetriggerList : "+filePath);
            Process p = Runtime.getRuntime().exec(filePath);
            Thread.sleep(30000); 
        } catch (Exception e) {
            e.printStackTrace();
        }
		}
		
		return new ModelAndView("tsRetriggerPage");
	}
	
	
	
	@RequestMapping(value = "/download", method = RequestMethod.GET)
	public ResponseEntity<Object> downloadFile(@RequestParam("fileName") String fileName) throws IOException {

		System.out.println("Method inside...download.." + fileName);
		// String filename = "D:/work/tree.jpg";
		String filename = folderpath + "/" + fileName;
		// sString filename = fileName;
		File file = new File(filename);
		InputStreamResource resource = new InputStreamResource(new FileInputStream(file));

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", String.format("attachment; filename=\"%s\"", file.getName()));
		headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
		headers.add("Pragma", "no-cache");
		headers.add("Expires", "0");

		ResponseEntity<Object> responseEntity = ResponseEntity.ok().headers(headers).contentLength(file.length())
				.contentType(MediaType.parseMediaType("application/pdf")).body(resource);

		return responseEntity;
	}
	

}
