package com.scb.ts.reportapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportappApplicationTests {

	@Test
	void contextLoads() {
	}

}
