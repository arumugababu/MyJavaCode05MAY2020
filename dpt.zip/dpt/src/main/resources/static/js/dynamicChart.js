document.addEventListener("DOMContentLoaded", function () {
    fetch("/api/dynamic-chart/config")
        .then(response => response.json())
        .then(data => {
            populateDropdown("country", data.countries);
            populateDropdown("paymentType", data.paymentTypes);
            populateCheckboxes("statusContainer", data.statuses);
        });

    document.getElementById("dataForm").addEventListener("submit", function (event) {
        event.preventDefault();
        document.getElementById("loadingIcon").style.display = "block";

        const formData = new FormData(this);
        const filters = Object.fromEntries(formData.entries());
        filters.status = Array.from(document.querySelectorAll("input[name='status']:checked")).map(cb => cb.value);

        fetch("/api/dynamic-chart/process", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(filters)
        })
        .then(response => response.json())
        .then(filePaths => {
            document.getElementById("loadingIcon").style.display = "none";
            renderChart(filePaths);
            generateDownloadButtons(filePaths);
        });
    });
});

function populateDropdown(elementId, values) {
    const dropdown = document.getElementById(elementId);
    values.forEach(value => {
        let option = document.createElement("option");
        option.value = value;
        option.textContent = value;
        dropdown.appendChild(option);
    });
}

function populateCheckboxes(containerId, values) {
    const container = document.getElementById(containerId);
    values.forEach(value => {
        let label = document.createElement("label");
        let checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.name = "status";
        checkbox.value = value;
        label.appendChild(checkbox);
        label.appendChild(document.createTextNode(" " + value));
        container.appendChild(label);
        container.appendChild(document.createElement("br"));
    });
}

function renderChart(data) {
    let ctx = document.getElementById("dataChart").getContext("2d");
    let labels = Object.keys(data);
    let values = Object.values(data).map(arr => arr.length);

    if (window.chartInstance) {
        window.chartInstance.destroy();
    }

    window.chartInstance = new Chart(ctx, {
        type: "pie",
        data: {
            labels: labels,
            datasets: [{
                data: values,
                backgroundColor: ["red", "blue", "green", "yellow"]
            }]
        }
    });
}

function generateDownloadButtons(filePaths) {
    const container = document.getElementById("downloadButtons");
    container.innerHTML = "";
    Object.keys(filePaths).forEach(status => {
        let button = document.createElement("button");
        button.textContent = "Download " + status + " Data";
        button.onclick = () => window.location.href = "/api/dynamic-chart/download?status=" + status;
        container.appendChild(button);
    });
}
