package com.dpt.model;

public class QueryResult {
    private String filePath;
    private String executedQuery;

    public QueryResult(String filePath, String executedQuery) {
        this.filePath = filePath;
        this.executedQuery = executedQuery;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getExecutedQuery() {
        return executedQuery;
    }
}