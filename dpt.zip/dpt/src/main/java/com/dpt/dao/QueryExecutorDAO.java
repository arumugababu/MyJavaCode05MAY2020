package com.dpt.dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class QueryExecutorDAO {

    @PersistenceContext
    private EntityManager entityManager;

    public List<String[]> executeQuery(String queryString) {
        Query query = entityManager.createNativeQuery(queryString);
        @SuppressWarnings("unchecked")
        List<Object[]> results = query.getResultList();

        return results.stream()
                .map(row -> {
                    String[] stringRow = new String[row.length];
                    for (int i = 0; i < row.length; i++) {
                        stringRow[i] = (row[i] != null) ? row[i].toString() : "";
                    }
                    return stringRow;
                })
                .toList();
    }
}
