package com.dpt.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dpt.config.DynamicConfigChart;
import com.dpt.model.TransactionChart;
import com.dpt.service.QueryExecutorService;

@Controller
public class ChartController {
	
	@Autowired
	private QueryExecutorService queryExecutorService;
	
	@Autowired
	private TransactionChart transactionChart;
	
	private final DynamicConfigChart dynamicChartConfig;

    @Autowired
    public ChartController(DynamicConfigChart dynamicChartConfig) {
        this.dynamicChartConfig = dynamicChartConfig;
    }

    @GetMapping("/chatpage")
    public String chatpage(Model model) {
        Map<String, String> fields = dynamicChartConfig.getFields();
        Map<String, String> labels = dynamicChartConfig.getLabels();

        Map<String, List<String>> checkboxValues = new HashMap<>();
        Map<String, String> firstValues = new HashMap<>();

        // Debugging: Print values to ensure data is loaded
        System.out.println("Fields Loaded: " + fields);
        System.out.println("Labels Loaded: " + labels);

        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String[] values = entry.getValue().split(",");
            if (values.length > 1) {
                firstValues.put(entry.getKey(), values[0]);
                checkboxValues.put(entry.getKey(), Arrays.asList(Arrays.copyOfRange(values, 1, values.length)));
            } else {
                firstValues.put(entry.getKey(), entry.getValue());
            }
        }

        // Debugging: Check processed values
        System.out.println("First Values: " + firstValues);
        System.out.println("Checkbox Values: " + checkboxValues);

        model.addAttribute("firstValues", firstValues);
        model.addAttribute("checkboxValues", checkboxValues);
        model.addAttribute("labels", labels);

        return "chatpage";
    }
    
    @PostMapping("/chartprocess")
	public String chartDataProcessing(@RequestParam MultiValueMap<String, String> formData, Model model) {
		if (formData.isEmpty()) {
			return "No data received!";
		}

		DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);

		formData.forEach((key, values) -> {
			if (key.toLowerCase().contains("date")) {
				for (int i = 0; i < values.size(); i++) {
					try {
						LocalDate date = LocalDate.parse(values.get(i), inputFormatter);
						values.set(i, date.format(outputFormatter));
					} catch (Exception e) {
						System.err
								.println("Skipping invalid date format for key: " + key + ", value: " + values.get(i));
					}
				}
			}
		});

		String filePath = null;
		try {
			//filePath = queryExecutorService.executeQueryAndGenerateCSV(formData);
		} catch (Exception e) {
			e.printStackTrace();
		}

		model.addAttribute("filePath", filePath);
		return "success"; // Redirect to the new success page
	}

}
