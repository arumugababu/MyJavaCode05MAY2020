package com.dpt.config;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import jakarta.annotation.PostConstruct;

@Configuration
@ConfigurationProperties(prefix = "dynamic")
public class DynamicConfig {

    private Map<String, String> fields;
    private Map<String, String> labels;

    // Getters and Setters
    public Map<String, String> getFields() {
        return fields;
    }

    public void setFields(Map<String, String> fields) {
        this.fields = fields;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }

    @PostConstruct
    public void init() {
        System.out.println("Fields: " + fields);
        System.out.println("Labels: " + labels);
    }
}
