package com.dpt.config;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import jakarta.annotation.PostConstruct;

@Configuration
@ConfigurationProperties(prefix = "dynamicchart")
public class DynamicConfigChart {

	   private final Map<String, String> fields = new LinkedHashMap<>();
	    private final Map<String, String> labels = new LinkedHashMap<>();

	    public Map<String, String> getFields() {
	        return fields;
	    }

	    public Map<String, String> getLabels() {
	        return labels;
	    }
	    
    @PostConstruct
    public void init() {
        System.out.println("Fields: " + fields);
        System.out.println("Labels: " + labels);
    }
}
