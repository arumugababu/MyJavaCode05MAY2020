package com.dpt.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class QueryBuilderUtil {

    private static String selectFields;
    private static String orderByFields;
    private static int chunkSize; // ✅ New chunk size configuration
    
    private static String dynamictable;

    @Value("${dynamic.table}")
    public void setDynamicTable(String dynamicTable) {
        QueryBuilderUtil.dynamictable = dynamicTable;
    }

   /* @Value("${dynamic.selectfields}")
    public void setSelectFields(String selectFields) {
        QueryBuilderUtil.selectFields = selectFields;
    }*/

    @Value("${dynamic.orderby}")
    public void setOrderByFields(String orderByFields) {
        QueryBuilderUtil.orderByFields = orderByFields;
    }

    @Value("${query.chunk.days}")  
    public void setChunkSize(int chunkSize) {
        QueryBuilderUtil.chunkSize = chunkSize;
    }

    
    public static List<String> buildChunkedQueries(MultiValueMap<String, String> formData) {
        List<String> queries = new ArrayList<>();
        
        String selectedFields = formData.entrySet().stream()
                .filter(entry -> entry.getValue().contains("on")) // Check if "on" is present in values
                .map(Map.Entry::getKey) // Get the keys
                .collect(Collectors.joining(", ")); // Join as comma-separated string

        // Output the result
        System.out.println("My value check"+selectedFields);

        String baseQuery = "SELECT " + selectedFields + " FROM "+ dynamictable +" WHERE ";

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");

        // ✅ Extract 'createdate' range
        List<String> createdDates = formData.get("createdate");
        if (createdDates != null && createdDates.size() == 2) {
            LocalDate startDate = LocalDate.parse(createdDates.get(0), formatter);
            LocalDate endDate = LocalDate.parse(createdDates.get(1), formatter);

            while (!startDate.isAfter(endDate)) {
                LocalDate tempEnd = startDate.plusDays(chunkSize - 1);
                if (tempEnd.isAfter(endDate)) {
                    tempEnd = endDate;
                }

                // ✅ Use StringBuilder inside loop
                StringBuilder chunkQueryBuilder = new StringBuilder(baseQuery);
                chunkQueryBuilder.append(" createdate BETWEEN TO_DATE('")
                        .append(startDate.format(formatter)).append("', 'DD-MON-YYYY') AND TO_DATE('")
                        .append(tempEnd.format(formatter)).append("', 'DD-MON-YYYY')");

                // ✅ Append additional filters
                formData.forEach((key, values) -> {
                    if (!key.equalsIgnoreCase("createdate")) {
                        List<String> validValues = values.stream()
                                .filter(value -> value != null && !value.isEmpty())
                                .collect(Collectors.toList());

                   /*     if (!validValues.isEmpty()) {
                            String condition = validValues.stream()
                                    .map(value -> "'" + value + "'")
                                    .collect(Collectors.joining(", "));
                            chunkQueryBuilder.append(" AND ").append(key).append(" IN (").append(condition).append(")");
                        }
                    }*/
                        
                        if (!validValues.isEmpty()) {
                            // Filter out "on" values
                            List<String> filteredValues = validValues.stream()
                                    .filter(value -> !"on".equals(value)) // Ignore "on" values
                                    .collect(Collectors.toList());

                            /*if (!filteredValues.isEmpty()) { // Only append if there are valid values left
                                String condition = filteredValues.stream()
                                        .map(value -> "'" + value + "'")
                                        .collect(Collectors.joining(", "));
                                chunkQueryBuilder.append(" AND ").append(key).append(" IN (").append(condition).append(")");
                            }*/
                            
                           /* if (!filteredValues.isEmpty()) { // Only append if there are valid values left
                                String condition = filteredValues.stream()
                                        .map(value -> "'" + value.trim() + "'") // Trim spaces and wrap in single quotes
                                        .collect(Collectors.joining(", "));

                                chunkQueryBuilder.append(" AND ").append(key).append(" IN (").append(condition).append(")");
                            }*/

                            if (!filteredValues.isEmpty()) { // Only append if there are valid values left
                                String condition = filteredValues.stream()
                                        .flatMap(val -> { 
                                            String[] splitValues = val.split(","); // Renamed from 'values' to 'splitValues'
                                            return Arrays.stream(splitValues).map(v -> "'" + v.trim() + "'");
                                        })
                                        .collect(Collectors.joining(", ")); // Join with a comma and space

                                chunkQueryBuilder.append(" AND ").append(key).append(" IN (").append(condition).append(")");
                            }



                            
                        }}
                });

                // ✅ Append GROUP BY Clause
                if (orderByFields != null && !orderByFields.trim().isEmpty()) {
                    //chunkQueryBuilder.append(" GROUP BY ").append(orderByFields);
                    chunkQueryBuilder.append(" GROUP BY ").append(selectedFields);
                }

                queries.add(chunkQueryBuilder.toString());
                startDate = tempEnd.plusDays(1);
            }
        }

        return queries;
    }

    
}
