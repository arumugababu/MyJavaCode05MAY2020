package com.dpt.service;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.dpt.dao.QueryExecutorDAO;
import com.dpt.model.QueryResult;
import com.dpt.util.QueryBuilderUtil;
import com.opencsv.CSVWriter;

@Service
public class QueryExecutorService {

    private final QueryExecutorDAO queryExecutorDAO;

   /* @Value("${dynamic.selectfields}")
    private String selectFields;
    */
    //@Value("${dynamic.selectfields}")
    private String selectedFields;

    public QueryExecutorService(QueryExecutorDAO queryExecutorDAO) {
        this.queryExecutorDAO = queryExecutorDAO;
    }

    public QueryResult executeQueryAndGenerateCSV(MultiValueMap<String, String> formData) throws Exception {
        // ✅ QueryBuilderUtil now handles chunking & query creation
        List<String> queries = QueryBuilderUtil.buildChunkedQueries(formData);
        
         selectedFields = formData.entrySet().stream()
                .filter(entry -> entry.getValue().contains("on")) // Check if "on" is present in values
                .map(Map.Entry::getKey) // Get the keys
                .collect(Collectors.joining(", ")); // Join as comma-separated string

        // Output the result
        System.out.println("My value check"+selectedFields);

        // ✅ Execute queries using ThreadPoolExecutor
        ExecutorService executorService = Executors.newFixedThreadPool(queries.size());
        List<Future<List<String[]>>> futures = new ArrayList<>();
        
        for (String query : queries) {
            futures.add(executorService.submit(() -> queryExecutorDAO.executeQuery(query)));
        }

        // ✅ Collect results
        List<String[]> allResults = new ArrayList<>();
        for (Future<List<String[]>> future : futures) {
            allResults.addAll(future.get());
        }

        executorService.shutdown();
        String executedQuery = queries.get(0);
        String filePath = writeResultsToCSV(allResults);
        return new QueryResult(filePath, executedQuery);
    }

    private String writeResultsToCSV(List<String[]> data) throws IOException {
        String filePath = "output.csv";
        try (CSVWriter writer = new CSVWriter(new FileWriter(filePath))) {
            writer.writeNext(selectedFields.split(",")); 
            writer.writeAll(data);
        }
        return filePath;
    }
}
